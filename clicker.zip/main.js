function f(id){
    return document.getElementById(id);
}
function fc(c){
    return document.getElementsByClassName(c)[0];
}
function evaluateToolTips(){
    tooltips = document.getElementsByTagName("*");
    for(var i = 0; i < tooltips.length; i++){
            tooltips[i].addEventListener("mouseover", function(event){
                if(event.target.getAttribute("tooltip") != null){
                    f("tt").style.display = "block"
                    f("tt").innerHTML = event.target.getAttribute("tooltip")
                }
            })
            tooltips[i].addEventListener("mouseout", function(event){
                if(event.target.getAttribute("tooltip") != null){
                    f("tt").style.display = "none"
                }
            })
    }
}
var Game = {
    "buttonClicks": 0,
    clickButton: function(){
        f("clickerButtonBig").click;
    },
    notification: function(content){
        var notif = document.createElement("div");
        notif.classList.add("notification");
        notif.setAttribute("tooltip", "Click to hide notification")
        notif.innerHTML = content;
        notif.addEventListener("click", function(event){
            event.target.remove();
            f("tt").style.display = "none"
        });
        console.log(notif)
        fc("notificationBox").appendChild(notif);
    },
    "seeds": 0,
    "spc": 1,
    "Garden": {
        "planted": [],
        "plants": {
            "Grass": {
                "displayName": "Grass",
                "rarity": "Common",
                "cost": 50,
                "sps": 1
            },
            "Lavender": {
                "displayName": "Lavender",
                "rarity": "Common",
                "cost": 500,
                "sps": 5
            },
            "Carrots": {
                "displayName": "Carrots",
                "rarity": "Uncommon",
                "cost": 2000,
                "sps": 7
            }
        }
    }
};
var tooltips
document.addEventListener("DOMContentLoaded", function(){
    f("clickerButtonBig").addEventListener("click", function(){
        Game.seeds += Game.spc
    });  
    setInterval(() => {
        f("seedDisplay").innerHTML = "<span class='textHighlight green'>" + Game.seeds + "</span> seeds"
    }, 10);
    for(var key in Game.Garden.plants){
        var elem = document.createElement("td");
        var div = document.createElement("div");
        div.classList.add(key);
        div.classList.add("gardenPlant");
        elem.appendChild(div);
        elem.classList.add("gPlantWrapper")
        /*elem.setAttribute("tooltip", 
            key + "<br><hr>" +
            "Cost: " + Game.Garden.plants[key].cost + " seeds<br>" +
            "SPS: " + Game.Garden.plants[key].sps + "<br>"
        );*/
        div.setAttribute("tooltip", 
            key + "<br><hr>" +
            "Cost: " + Game.Garden.plants[key].cost + " seeds<br>" +
            "SPS: " + Game.Garden.plants[key].sps + "<br>"
        );
        div.addEventListener("click", function(event){
            if(Game.seeds >= Game.Garden.plants[key].cost){
                alert("you smell like voineger")
            }else{
                Game.notification("Not enough seeds!");
            }
        })
        f("gardenPlantList").appendChild(elem);
    };

    
    document.addEventListener("mousemove", function(event){
        f("tt").style.top = (event.pageY + 5) + "px"
        f("tt").style.left = event.pageX + "px"
    })
    Game.notification("Welcome!")
    evaluateToolTips();
})